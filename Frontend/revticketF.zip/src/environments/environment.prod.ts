export const environment = {
  production: true,
  apiUrl: 'https://api.revticket.com/api'
};