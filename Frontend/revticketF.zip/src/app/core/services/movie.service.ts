import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { Movie, Showtime } from '../models/movie.model';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class MovieService {
  constructor(private http: HttpClient) {}

  getMovies(): Observable<Movie[]> {
    if (environment.production) {
      return this.http.get<Movie[]>(`${environment.apiUrl}/movies`);
    } else {
      return this.getMockMovies();
    }
  }

  private getMockMovies(): Observable<Movie[]> {
    const mockMovies: Movie[] = [
      {
        id: '1',
        title: 'Avengers: Endgame',
        description: 'The epic conclusion to the Infinity Saga.',
        genre: ['Action', 'Adventure', 'Drama'],
        duration: 181,
        rating: 8.4,
        releaseDate: new Date('2019-04-26'),
        posterUrl: 'https://image.tmdb.org/t/p/w500/or06FN3Dka5tukK1e9sl16pB3iy.jpg',
        trailerUrl: 'https://youtube.com/watch?v=TcMBFSGVi1c',
        language: 'English',
        isActive: true
      },
      {
        id: '2',
        title: 'Spider-Man: No Way Home',
        description: 'Spider-Man faces his greatest challenge yet.',
        genre: ['Action', 'Adventure', 'Sci-Fi'],
        duration: 148,
        rating: 8.2,
        releaseDate: new Date('2021-12-17'),
        posterUrl: 'https://image.tmdb.org/t/p/w500/1g0dhYtq4irTY1GPXvft6k4YLjm.jpg',
        language: 'English',
        isActive: true
      },
      {
        id: '3',
        title: 'The Batman',
        description: 'A new take on the Dark Knight.',
        genre: ['Action', 'Crime', 'Drama'],
        duration: 176,
        rating: 7.8,
        releaseDate: new Date('2022-03-04'),
        posterUrl: 'https://image.tmdb.org/t/p/w500/b0PlSFdDwbyK0cf5RxwDpaOJQvQ.jpg',
        language: 'English',
        isActive: true
      },
      {
        id: '4',
        title: 'Top Gun: Maverick',
        description: 'After thirty years, Maverick is still pushing the envelope.',
        genre: ['Action', 'Drama'],
        duration: 130,
        rating: 8.3,
        releaseDate: new Date('2022-05-27'),
        posterUrl: 'https://image.tmdb.org/t/p/w500/62HCnUTziyWcpDaBO2i1DX17ljH.jpg',
        language: 'English',
        isActive: true
      }
    ];
    return of(mockMovies);
  }

  getMovieById(id: string): Observable<Movie> {
    if (environment.production) {
      return this.http.get<Movie>(`${environment.apiUrl}/movies/${id}`);
    } else {
      const movies = [
        {
          id: '1',
          title: 'Avengers: Endgame',
          description: 'The epic conclusion to the Infinity Saga.',
          genre: ['Action', 'Adventure', 'Drama'],
          duration: 181,
          rating: 8.4,
          releaseDate: new Date('2019-04-26'),
          posterUrl: 'https://image.tmdb.org/t/p/w500/or06FN3Dka5tukK1e9sl16pB3iy.jpg',
          trailerUrl: 'https://youtube.com/watch?v=TcMBFSGVi1c',
          language: 'English',
          isActive: true
        },
        {
          id: '2',
          title: 'Spider-Man: No Way Home',
          description: 'Spider-Man faces his greatest challenge yet.',
          genre: ['Action', 'Adventure', 'Sci-Fi'],
          duration: 148,
          rating: 8.2,
          releaseDate: new Date('2021-12-17'),
          posterUrl: 'https://image.tmdb.org/t/p/w500/1g0dhYtq4irTY1GPXvft6k4YLjm.jpg',
          language: 'English',
          isActive: true
        },
        {
          id: '3',
          title: 'The Batman',
          description: 'A new take on the Dark Knight.',
          genre: ['Action', 'Crime', 'Drama'],
          duration: 176,
          rating: 7.8,
          releaseDate: new Date('2022-03-04'),
          posterUrl: 'https://image.tmdb.org/t/p/w500/b0PlSFdDwbyK0cf5RxwDpaOJQvQ.jpg',
          language: 'English',
          isActive: true
        },
        {
          id: '4',
          title: 'Top Gun: Maverick',
          description: 'After thirty years, Maverick is still pushing the envelope.',
          genre: ['Action', 'Drama'],
          duration: 130,
          rating: 8.3,
          releaseDate: new Date('2022-05-27'),
          posterUrl: 'https://image.tmdb.org/t/p/w500/62HCnUTziyWcpDaBO2i1DX17ljH.jpg',
          language: 'English',
          isActive: true
        }
      ];
      const movie = movies.find(m => m.id === id);
      return of(movie || movies[0]);
    }
  }

  getShowtimes(movieId: string, date?: string): Observable<Showtime[]> {
    const options = date ? { params: { date } } : {};
    return this.http.get<Showtime[]>(`${environment.apiUrl}/movies/${movieId}/showtimes`, options);
  }

  addMovie(movie: Partial<Movie>): Observable<Movie> {
    return this.http.post<Movie>(`${environment.apiUrl}/movies`, movie);
  }

  updateMovie(id: string, movie: Partial<Movie>): Observable<Movie> {
    return this.http.put<Movie>(`${environment.apiUrl}/movies/${id}`, movie);
  }

  deleteMovie(id: string): Observable<void> {
    return this.http.delete<void>(`${environment.apiUrl}/movies/${id}`);
  }
}