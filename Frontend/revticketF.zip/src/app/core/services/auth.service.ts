import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { tap } from 'rxjs/operators';
import { User, LoginRequest, SignupRequest, AuthResponse } from '../models/user.model';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private currentUserSubject = new BehaviorSubject<User | null>(null);
  public currentUser$ = this.currentUserSubject.asObservable();

  constructor(private http: HttpClient) {
    this.loadUserFromStorage();
  }

  login(credentials: LoginRequest): Observable<AuthResponse> {
    // Mock authentication for development
    if (environment.production) {
      return this.http.post<AuthResponse>(`${environment.apiUrl}/auth/login`, credentials)
        .pipe(tap(response => this.setCurrentUser(response)));
    } else {
      return this.mockLogin(credentials)
        .pipe(tap(response => this.setCurrentUser(response)));
    }
  }

  private mockLogin(credentials: LoginRequest): Observable<AuthResponse> {
    if (credentials.email === 'admin@revticket.com' && credentials.password === 'admin123') {
      return of({
        token: 'mock-admin-token',
        user: {
          id: 'admin-1',
          email: 'admin@revticket.com',
          name: 'Admin User',
          role: 'ADMIN',
          createdAt: new Date()
        }
      });
    }
    else if (credentials.email === 'user@revticket.com' && credentials.password === 'user123') {
      return of({
        token: 'mock-user-token',
        user: {
          id: 'user-1',
          email: 'user@revticket.com',
          name: 'Test User',
          role: 'USER',
          createdAt: new Date()
        }
      });
    }
    else {
      throw new Error('Invalid credentials');
    }
  }

  signup(userData: SignupRequest): Observable<AuthResponse> {
    if (environment.production) {
      return this.http.post<AuthResponse>(`${environment.apiUrl}/auth/signup`, userData)
        .pipe(tap(response => this.setCurrentUser(response)));
    } else {
      return this.mockSignup(userData)
        .pipe(tap(response => this.setCurrentUser(response)));
    }
  }

  private mockSignup(userData: SignupRequest): Observable<AuthResponse> {
    if (userData.email && userData.password && userData.name) {
      return of({
        token: 'mock-user-token',
        user: {
          id: 'user-' + Date.now(),
          email: userData.email,
          name: userData.name,
          role: 'USER',
          phone: userData.phone,
          createdAt: new Date()
        }
      });
    } else {
      throw new Error('Invalid signup data');
    }
  }

  logout(): void {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    this.currentUserSubject.next(null);
  }

  isAuthenticated(): boolean {
    return !!localStorage.getItem('token');
  }

  isAdmin(): boolean {
    const user = this.currentUserSubject.value;
    return user?.role === 'ADMIN';
  }

  private setCurrentUser(authResponse: AuthResponse): void {
    localStorage.setItem('token', authResponse.token);
    localStorage.setItem('user', JSON.stringify(authResponse.user));
    this.currentUserSubject.next(authResponse.user);
  }

  getCurrentUser(): User | null {
    return this.currentUserSubject.value;
  }

  forgotPassword(email: string): Observable<any> {
    if (environment.production) {
      return this.http.post(`${environment.apiUrl}/auth/forgot-password`, { email });
    } else {
      return this.mockForgotPassword(email);
    }
  }

  private mockForgotPassword(email: string): Observable<any> {
    // Mock email validation
    const validEmails = ['user@revticket.com', 'admin@revticket.com', 'test@example.com'];
    
    if (validEmails.includes(email)) {
      console.log(`Mock: Password reset email sent to ${email}`);
      return of({ message: 'Password reset email sent successfully' });
    } else {
      throw new Error('Email not found');
    }
  }

  private loadUserFromStorage(): void {
    const userStr = localStorage.getItem('user');
    if (userStr) {
      this.currentUserSubject.next(JSON.parse(userStr));
    }
  }
}