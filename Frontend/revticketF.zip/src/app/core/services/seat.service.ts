import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { SeatLayout, SeatAvailability, Seat, SeatType } from '../models/seat.model';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class SeatService {
  constructor(private http: HttpClient) {}

  getSeatLayout(showtimeId: string): Observable<SeatLayout> {
    const mockSeats: Seat[] = [];
    const rows = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
    
    rows.forEach(row => {
      for (let i = 1; i <= 12; i++) {
        mockSeats.push({
          id: `${row}${i}`,
          row,
          number: i,
          isBooked: Math.random() < 0.2,
          isHeld: false,
          price: ['A', 'B'].includes(row) ? 150 : ['C', 'D', 'E'].includes(row) ? 200 : 300,
          type: ['A', 'B'].includes(row) ? SeatType.REGULAR : ['C', 'D', 'E'].includes(row) ? SeatType.PREMIUM : SeatType.VIP
        });
      }
    });

    const mockLayout: SeatLayout = {
      showtimeId,
      theater: 'PVR Cinemas',
      screen: 'Screen 1',
      totalSeats: mockSeats.length,
      availableSeats: mockSeats.filter(s => !s.isBooked).length,
      seats: mockSeats,
      rows,
      seatsPerRow: 12
    };

    return of(mockLayout);
  }

  holdSeats(showtimeId: string, seatIds: string[]): Observable<void> {
    return of(void 0);
  }

  releaseSeats(showtimeId: string, seatIds: string[]): Observable<void> {
    return of(void 0);
  }

  getRealTimeAvailability(showtimeId: string): Observable<SeatAvailability[]> {
    return of([]);
  }

  extendSeatHold(showtimeId: string, seatIds: string[]): Observable<void> {
    return of(void 0);
  }
}