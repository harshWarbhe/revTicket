import { Injectable } from '@angular/core';
import { Observable, of, delay } from 'rxjs';
import { Booking, BookingRequest, PaymentRequest } from '../models/booking.model';

@Injectable({
  providedIn: 'root'
})
export class BookingService {
  private mockBookings: Booking[] = [
    {
      id: '1',
      userId: 'user1',
      movieId: '1',
      movieTitle: 'Avengers: Endgame',
      theaterId: '1',
      theaterName: 'PVR Cinemas',
      showtimeId: '1',
      showtime: new Date('2024-01-20T19:30:00'),
      seats: ['A1', 'A2'],
      totalAmount: 500,
      bookingDate: new Date('2024-01-15T10:30:00'),
      status: 'confirmed',
      customerName: 'John Doe',
      customerEmail: 'john@example.com',
      customerPhone: '+1234567890'
    },
    {
      id: '2',
      userId: 'user2',
      movieId: '2',
      movieTitle: 'Spider-Man: No Way Home',
      theaterId: '2',
      theaterName: 'INOX Multiplex',
      showtimeId: '2',
      showtime: new Date('2024-01-21T16:00:00'),
      seats: ['B5', 'B6', 'B7'],
      totalAmount: 600,
      bookingDate: new Date('2024-01-16T14:20:00'),
      status: 'confirmed',
      customerName: 'Jane Smith',
      customerEmail: 'jane@example.com',
      customerPhone: '+1234567891'
    },
    {
      id: '3',
      userId: 'user3',
      movieId: '3',
      movieTitle: 'The Batman',
      theaterId: '3',
      theaterName: 'Cinepolis',
      showtimeId: '3',
      showtime: new Date('2024-01-19T21:00:00'),
      seats: ['C10'],
      totalAmount: 300,
      bookingDate: new Date('2024-01-17T09:15:00'),
      status: 'cancelled',
      customerName: 'Mike Johnson',
      customerEmail: 'mike@example.com',
      customerPhone: '+1234567892'
    }
  ];

  constructor() {}

  createBooking(bookingData: BookingRequest): Observable<Booking> {
    const newBooking: Booking = {
      id: (this.mockBookings.length + 1).toString(),
      userId: 'current-user',
      movieId: bookingData.movieId,
      movieTitle: bookingData.movieTitle || 'Movie Title',
      theaterId: bookingData.theaterId,
      theaterName: bookingData.theaterName || 'Theater Name',
      showtimeId: bookingData.showtimeId,
      showtime: bookingData.showtime,
      seats: bookingData.seats,
      totalAmount: bookingData.totalAmount,
      bookingDate: new Date(),
      status: 'confirmed',
      customerName: bookingData.customerName || 'Customer',
      customerEmail: bookingData.customerEmail || 'customer@example.com',
      customerPhone: bookingData.customerPhone || '+1234567890',
      qrCode: this.generateQRCode((this.mockBookings.length + 1).toString()),
      ticketNumber: this.generateTicketNumber()
    };
    this.mockBookings.push(newBooking);
    return of(newBooking).pipe(delay(500));
  }

  getUserBookings(): Observable<Booking[]> {
    return of(this.mockBookings.filter(b => b.userId === 'current-user')).pipe(delay(300));
  }

  getBookingById(id: string): Observable<Booking> {
    const booking = this.mockBookings.find(b => b.id === id);
    return of(booking!).pipe(delay(300));
  }

  cancelBooking(id: string, reason?: string): Observable<{ refundAmount: number }> {
    const booking = this.mockBookings.find(b => b.id === id);
    if (booking) {
      booking.status = 'cancelled';
      booking.cancellationReason = reason;
      booking.refundAmount = this.calculateRefund(booking);
      booking.refundDate = new Date();
    }
    return of({ refundAmount: booking?.refundAmount || 0 }).pipe(delay(500));
  }

  generateQRCode(bookingId: string): string {
    return `QR_${bookingId}_${Date.now()}`;
  }

  generateTicketNumber(): string {
    return `TKT${Date.now().toString().slice(-8)}`;
  }

  private calculateRefund(booking: Booking): number {
    const showDate = new Date(booking.showtime);
    const now = new Date();
    const hoursUntilShow = (showDate.getTime() - now.getTime()) / (1000 * 60 * 60);
    
    if (hoursUntilShow > 24) return booking.totalAmount * 0.9;
    if (hoursUntilShow > 4) return booking.totalAmount * 0.5;
    return 0;
  }

  getAllBookings(): Observable<Booking[]> {
    return of(this.mockBookings).pipe(delay(300));
  }

  private currentBookingData: any = null;

  setCurrentBooking(data: any): void {
    this.currentBookingData = data;
  }

  getCurrentBooking(): any {
    return this.currentBookingData;
  }
}