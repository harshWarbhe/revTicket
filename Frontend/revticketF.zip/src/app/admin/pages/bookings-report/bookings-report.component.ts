import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AlertService } from '../../../core/services/alert.service';

@Component({
  selector: 'app-bookings-report',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './bookings-report.component.html',
  styleUrls: ['./bookings-report.component.css']
})
export class BookingsReportComponent implements OnInit {
  // Summary data
  totalBookings = 1247;
  totalRevenue = 312450;
  todayBookings = 23;
  avgTicketsPerBooking = 2.3;

  // Filter properties
  fromDate = '';
  toDate = '';
  selectedMovie = '';
  selectedTheater = '';
  selectedStatus = '';
  searchTerm = '';

  // Pagination
  currentPage = 1;
  itemsPerPage = 10;
  totalPages = 1;

  // Sample bookings data
  bookings = [
    {
      id: 'BK001',
      customerName: 'John Doe',
      customerEmail: 'john@example.com',
      movieTitle: 'Avengers: Endgame',
      theaterName: 'PVR Cinemas',
      showDate: new Date('2024-01-20T19:30:00'),
      seats: ['A1', 'A2'],
      totalAmount: 500,
      status: 'Confirmed'
    },
    {
      id: 'BK002',
      customerName: 'Jane Smith',
      customerEmail: 'jane@example.com',
      movieTitle: 'Spider-Man: No Way Home',
      theaterName: 'INOX Multiplex',
      showDate: new Date('2024-01-20T16:00:00'),
      seats: ['B5', 'B6', 'B7'],
      totalAmount: 750,
      status: 'Confirmed'
    },
    {
      id: 'BK003',
      customerName: 'Mike Johnson',
      customerEmail: 'mike@example.com',
      movieTitle: 'The Batman',
      theaterName: 'Cinepolis',
      showDate: new Date('2024-01-19T21:00:00'),
      seats: ['C3', 'C4'],
      totalAmount: 600,
      status: 'Cancelled'
    },
    {
      id: 'BK004',
      customerName: 'Sarah Wilson',
      customerEmail: 'sarah@example.com',
      movieTitle: 'Avengers: Endgame',
      theaterName: 'PVR Cinemas',
      showDate: new Date('2024-01-21T14:30:00'),
      seats: ['D1'],
      totalAmount: 250,
      status: 'Pending'
    },
    {
      id: 'BK005',
      customerName: 'David Brown',
      customerEmail: 'david@example.com',
      movieTitle: 'Spider-Man: No Way Home',
      theaterName: 'INOX Multiplex',
      showDate: new Date('2024-01-21T19:00:00'),
      seats: ['E5', 'E6', 'E7', 'E8'],
      totalAmount: 1000,
      status: 'Confirmed'
    }
  ];

  filteredBookings = [...this.bookings];

  constructor(private alertService: AlertService) {}

  ngOnInit(): void {
    this.setDefaultDates();
    this.filterBookings();
    this.updatePagination();
  }

  setDefaultDates(): void {
    const today = new Date();
    const lastMonth = new Date(today.getFullYear(), today.getMonth() - 1, today.getDate());
    
    this.fromDate = lastMonth.toISOString().split('T')[0];
    this.toDate = today.toISOString().split('T')[0];
  }

  onFilterChange(): void {
    this.filterBookings();
    this.currentPage = 1;
    this.updatePagination();
  }

  onSearch(): void {
    this.filterBookings();
    this.currentPage = 1;
    this.updatePagination();
  }

  filterBookings(): void {
    this.filteredBookings = this.bookings.filter(booking => {
      // Date filter
      let matchesDate = true;
      if (this.fromDate && this.toDate) {
        const bookingDate = new Date(booking.showDate);
        const from = new Date(this.fromDate);
        const to = new Date(this.toDate);
        matchesDate = bookingDate >= from && bookingDate <= to;
      }

      // Search filter
      const matchesSearch = !this.searchTerm || 
        booking.customerName.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
        booking.customerEmail.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
        booking.id.toLowerCase().includes(this.searchTerm.toLowerCase());

      // Movie filter
      const matchesMovie = !this.selectedMovie || booking.movieTitle === this.selectedMovie;

      // Theater filter
      const matchesTheater = !this.selectedTheater || booking.theaterName === this.selectedTheater;

      // Status filter
      const matchesStatus = !this.selectedStatus || booking.status === this.selectedStatus;

      return matchesDate && matchesSearch && matchesMovie && matchesTheater && matchesStatus;
    });
  }

  updatePagination(): void {
    this.totalPages = Math.ceil(this.filteredBookings.length / this.itemsPerPage);
  }

  get paginatedBookings() {
    const start = (this.currentPage - 1) * this.itemsPerPage;
    const end = start + this.itemsPerPage;
    return this.filteredBookings.slice(start, end);
  }

  previousPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }

  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
    }
  }

  exportReport(): void {
    this.alertService.success('Report exported successfully!');
  }

  refreshData(): void {
    this.alertService.info('Data refreshed!');
    // Simulate data refresh
    this.filterBookings();
    this.updatePagination();
  }

  viewBooking(booking: any): void {
    this.alertService.info(`Viewing booking details for ${booking.id}`);
  }

  downloadTicket(booking: any): void {
    this.alertService.success(`Ticket downloaded for booking ${booking.id}`);
  }

  getEndIndex(): number {
    return Math.min(this.currentPage * this.itemsPerPage, this.filteredBookings.length);
  }
}