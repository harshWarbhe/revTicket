import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, RouterModule, ActivatedRoute } from '@angular/router';
import { AlertService } from '../../../core/services/alert.service';

@Component({
  selector: 'app-add-movie',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './add-movie.component.html',
  styleUrls: ['./add-movie.component.css']
})
export class AddMovieComponent implements OnInit {
  movieForm: FormGroup;
  isEditMode = false;
  editingMovieId: string | null = null;
  loading = false;

  constructor(
    private fb: FormBuilder, 
    private router: Router,
    private route: ActivatedRoute,
    private alertService: AlertService
  ) {
    this.movieForm = this.fb.group({
      title: ['', Validators.required],
      description: ['', Validators.required],
      duration: ['', [Validators.required, Validators.min(1)]],
      rating: ['', Validators.required],
      genre: ['', Validators.required],
      language: ['', Validators.required],
      posterUrl: [''],
      showCount: [0],
      bookingCount: [0]
    });
  }

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      if (params['edit']) {
        this.isEditMode = true;
        this.editingMovieId = params['edit'];
        this.loadMovieForEdit();
      }
    });
  }

  loadMovieForEdit(): void {
    const movieData = localStorage.getItem('editMovie');
    if (movieData) {
      const movie = JSON.parse(movieData);
      this.movieForm.patchValue({
        title: movie.title,
        description: movie.description || 'Sample description',
        duration: movie.duration,
        rating: movie.rating,
        genre: Array.isArray(movie.genre) ? movie.genre.join(', ') : movie.genre,
        language: movie.language || 'English',
        posterUrl: movie.posterUrl || '',
        showCount: movie.showCount || 0,
        bookingCount: movie.bookingCount || 0
      });
      localStorage.removeItem('editMovie');
    }
  }

  onSubmit(): void {
    if (this.movieForm.valid) {
      this.loading = true;
      setTimeout(() => {
        if (this.isEditMode) {
          this.alertService.success('Movie updated successfully!');
        } else {
          this.alertService.success('Movie added successfully!');
        }
        this.loading = false;
        this.router.navigate(['/admin/manage-movies']);
      }, 1000);
    }
  }

  onCancel(): void {
    this.router.navigate(['/admin/manage-movies']);
  }

  getPageTitle(): string {
    return this.isEditMode ? 'Edit Movie' : 'Add New Movie';
  }

  getSubmitButtonText(): string {
    return this.isEditMode ? 'Update Movie' : 'Add Movie';
  }
}
