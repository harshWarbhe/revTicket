import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { BookingService } from '../../../core/services/booking.service';
import { MovieService } from '../../../core/services/movie.service';
import { AlertService } from '../../../core/services/alert.service';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  totalMovies = 0;
  totalBookings = 0;
  totalRevenue = 0;

  constructor(
    private movieService: MovieService,
    private bookingService: BookingService,
    private alertService: AlertService
  ) {}

  ngOnInit(): void {
    this.loadStats();
  }

  loadStats(): void {
    this.movieService.getMovies().subscribe(movies => {
      this.totalMovies = movies.length;
    });

    this.bookingService.getAllBookings().subscribe(bookings => {
      this.totalBookings = bookings.length;
      this.totalRevenue = bookings.reduce((sum, booking) => sum + booking.totalAmount, 0);
    });
  }

  refreshData(): void {
    this.loadStats();
    this.alertService.success('Dashboard data refreshed successfully!');
  }

  exportReport(): void {
    this.alertService.info('Export functionality will be available soon!');
  }
}