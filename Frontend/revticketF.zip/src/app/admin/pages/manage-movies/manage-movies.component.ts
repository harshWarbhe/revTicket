import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AlertService } from '../../../core/services/alert.service';

@Component({
  selector: 'app-manage-movies',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './manage-movies.component.html',
  styleUrls: ['./manage-movies.component.css']
})
export class ManageMoviesComponent implements OnInit {
  movies = [
    { id: '1', title: 'Avengers: Endgame', genre: 'Action', duration: 181, rating: 'UA', isActive: true, posterUrl: 'https://image.tmdb.org/t/p/w500/or06FN3Dka5tukK1e9sl16pB3iy.jpg', description: 'Epic superhero movie', showCount: 8, bookingCount: 45 },
    { id: '2', title: 'Spider-Man: No Way Home', genre: 'Action', duration: 148, rating: 'UA', isActive: true, posterUrl: 'https://image.tmdb.org/t/p/w500/1g0dhYtq4irTY1GPXvft6k4YLjm.jpg', description: 'Spider-Man multiverse adventure', showCount: 6, bookingCount: 32 },
    { id: '3', title: 'The Batman', genre: 'Action', duration: 176, rating: 'A', isActive: false, posterUrl: 'https://image.tmdb.org/t/p/w500/b0PlSFdDwbyK0cf5RxwDpaOJQvQ.jpg', description: 'Dark knight returns', showCount: 4, bookingCount: 18 }
  ];
  
  filteredMovies = [...this.movies];
  searchTerm = '';
  selectedGenre = '';
  selectedRating = '';

  constructor(
    private router: Router,
    private alertService: AlertService
  ) {}

  ngOnInit(): void {
    this.filterMovies();
  }

  onSearch(): void {
    this.filterMovies();
  }

  onFilterChange(): void {
    this.filterMovies();
  }

  filterMovies(): void {
    this.filteredMovies = this.movies.filter(movie => {
      const matchesSearch = !this.searchTerm || 
        movie.title.toLowerCase().includes(this.searchTerm.toLowerCase());
      const matchesGenre = !this.selectedGenre || movie.genre === this.selectedGenre;
      const matchesRating = !this.selectedRating || movie.rating === this.selectedRating;
      return matchesSearch && matchesGenre && matchesRating;
    });
  }

  onImageError(event: any): void {
    event.target.src = 'assets/images/movies/default-poster.png';
  }

  getShowCount(movieId: string): number {
    const movie = this.movies.find(m => m.id === movieId);
    return movie?.showCount || 0;
  }

  getBookingCount(movieId: string): number {
    const movie = this.movies.find(m => m.id === movieId);
    return movie?.bookingCount || 0;
  }

  editMovie(movie: any): void {
    localStorage.setItem('editMovie', JSON.stringify(movie));
    this.router.navigate(['/admin/add-movie'], { queryParams: { edit: movie.id } });
  }

  deleteMovie(movie: any): void {
    if (confirm(`Are you sure you want to delete "${movie.title}"?`)) {
      this.movies = this.movies.filter(m => m.id !== movie.id);
      this.filterMovies();
      this.alertService.success('Movie deleted successfully!');
    }
  }
}