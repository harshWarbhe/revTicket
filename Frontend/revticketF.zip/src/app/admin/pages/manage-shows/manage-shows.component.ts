import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AlertService } from '../../../core/services/alert.service';

@Component({
  selector: 'app-manage-shows',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './manage-shows.component.html',
  styleUrls: ['./manage-shows.component.css']
})
export class ManageShowsComponent implements OnInit {
  shows = [
    {
      id: '1',
      movie: { 
        title: 'Avengers: Endgame', 
        genre: 'Action', 
        duration: 181, 
        rating: 'UA',
        posterUrl: 'https://image.tmdb.org/t/p/w500/or06FN3Dka5tukK1e9sl16pB3iy.jpg'
      },
      theater: { name: 'PVR Cinemas' },
      screen: 'Screen 1',
      showtime: new Date('2024-01-20T19:30:00'),
      ticketPrice: 250,
      totalSeats: 100,
      availableSeats: 75,
      status: 'Active'
    },
    {
      id: '2',
      movie: { 
        title: 'Spider-Man: No Way Home', 
        genre: 'Action', 
        duration: 148, 
        rating: 'UA',
        posterUrl: 'https://image.tmdb.org/t/p/w500/1g0dhYtq4irTY1GPXvft6k4YLjm.jpg'
      },
      theater: { name: 'INOX Multiplex' },
      screen: 'Screen 2',
      showtime: new Date('2024-01-20T16:00:00'),
      ticketPrice: 200,
      totalSeats: 80,
      availableSeats: 45,
      status: 'Active'
    },
    {
      id: '3',
      movie: { 
        title: 'The Batman', 
        genre: 'Action', 
        duration: 176, 
        rating: 'A',
        posterUrl: 'https://image.tmdb.org/t/p/w500/b0PlSFdDwbyK0cf5RxwDpaOJQvQ.jpg'
      },
      theater: { name: 'Cinepolis' },
      screen: 'Screen 3',
      showtime: new Date('2024-01-19T21:00:00'),
      ticketPrice: 300,
      totalSeats: 120,
      availableSeats: 0,
      status: 'Completed'
    }
  ];

  filteredShows = [...this.shows];
  searchTerm = '';
  selectedMovie = '';
  selectedTheater = '';
  selectedDate = '';
  showAddForm = false;
  isEditMode = false;
  editingShowId: string | null = null;
  newShow = {
    movie: { title: '', genre: '', duration: 0, rating: '', posterUrl: '' },
    theater: { name: '' },
    screen: '',
    showtime: '',
    ticketPrice: 0,
    totalSeats: 0,
    status: 'Active'
  };

  constructor(private alertService: AlertService) {}

  ngOnInit(): void {
    this.filterShows();
  }

  onSearch(): void {
    this.filterShows();
  }

  onFilterChange(): void {
    this.filterShows();
  }

  filterShows(): void {
    this.filteredShows = this.shows.filter(show => {
      const matchesSearch = !this.searchTerm || 
        show.movie.title.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
        show.theater.name.toLowerCase().includes(this.searchTerm.toLowerCase());
      
      const matchesMovie = !this.selectedMovie || show.movie.title === this.selectedMovie;
      const matchesTheater = !this.selectedTheater || show.theater.name === this.selectedTheater;
      
      let matchesDate = true;
      if (this.selectedDate) {
        const showDate = new Date(show.showtime).toDateString();
        const filterDate = new Date(this.selectedDate).toDateString();
        matchesDate = showDate === filterDate;
      }
      
      return matchesSearch && matchesMovie && matchesTheater && matchesDate;
    });
  }

  onImageError(event: any): void {
    event.target.src = 'assets/images/movies/default-poster.png';
  }

  addNewShow(): void {
    this.isEditMode = false;
    this.editingShowId = null;
    this.showAddForm = true;
    this.resetForm();
  }

  resetForm(): void {
    this.newShow = {
      movie: { title: '', genre: '', duration: 0, rating: '', posterUrl: '' },
      theater: { name: '' },
      screen: '',
      showtime: '',
      ticketPrice: 0,
      totalSeats: 0,
      status: 'Active'
    };
  }

  saveShow(): void {
    if (this.validateForm()) {
      if (this.isEditMode && this.editingShowId) {
        const index = this.shows.findIndex(s => s.id === this.editingShowId);
        if (index !== -1) {
          this.shows[index] = {
            ...this.shows[index],
            movie: { ...this.newShow.movie },
            theater: { ...this.newShow.theater },
            screen: this.newShow.screen,
            showtime: new Date(this.newShow.showtime),
            ticketPrice: this.newShow.ticketPrice,
            totalSeats: this.newShow.totalSeats,
            availableSeats: this.newShow.totalSeats,
            status: this.newShow.status
          };
          this.alertService.success('Show updated successfully!');
        }
      } else {
        const show = {
          id: (this.shows.length + 1).toString(),
          movie: { ...this.newShow.movie },
          theater: { ...this.newShow.theater },
          screen: this.newShow.screen,
          showtime: new Date(this.newShow.showtime),
          ticketPrice: this.newShow.ticketPrice,
          totalSeats: this.newShow.totalSeats,
          availableSeats: this.newShow.totalSeats,
          status: 'Active'
        };
        this.shows.push(show);
        this.alertService.success('Show added successfully!');
      }
      
      this.filterShows();
      this.showAddForm = false;
      this.isEditMode = false;
      this.editingShowId = null;
    }
  }

  validateForm(): boolean {
    if (!this.newShow.movie.title || !this.newShow.theater.name || 
        !this.newShow.screen || !this.newShow.showtime ||
        this.newShow.ticketPrice <= 0 || this.newShow.totalSeats <= 0) {
      this.alertService.error('Please fill all required fields');
      return false;
    }
    return true;
  }

  cancelAdd(): void {
    this.showAddForm = false;
    this.isEditMode = false;
    this.editingShowId = null;
    this.resetForm();
  }

  editShow(show: any): void {
    this.isEditMode = true;
    this.editingShowId = show.id;
    this.showAddForm = true;
    
    // Format datetime for input
    const showDateTime = new Date(show.showtime);
    const formattedDateTime = showDateTime.toISOString().slice(0, 16);
    
    this.newShow = {
      movie: { ...show.movie },
      theater: { ...show.theater },
      screen: show.screen,
      showtime: formattedDateTime,
      ticketPrice: show.ticketPrice,
      totalSeats: show.totalSeats,
      status: show.status
    };
  }

  viewBookings(show: any): void {
    this.alertService.info(`View bookings for: ${show.movie.title}`);
  }

  deleteShow(show: any): void {
    if (confirm(`Are you sure you want to delete the show "${show.movie.title}" at ${show.theater.name}?`)) {
      this.shows = this.shows.filter(s => s.id !== show.id);
      this.filterShows();
      this.alertService.success('Show deleted successfully!');
    }
  }

  hasFilters(): boolean {
    return !!(this.searchTerm || this.selectedMovie || this.selectedTheater || this.selectedDate);
  }

  getEmptyStateMessage(): string {
    if (this.hasFilters()) {
      return 'No shows match your current filters. Try adjusting your search criteria.';
    }
    return 'No shows scheduled yet. Start by adding your first show.';
  }
}